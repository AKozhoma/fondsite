<?php if (in_array('administrator', $user->roles)): ?>
    <?php print $output; ?>
<?php endif; ?>